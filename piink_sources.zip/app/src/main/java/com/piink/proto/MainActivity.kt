package com.piink.proto

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.util.DisplayMetrics
import android.widget.Button
import android.widget.TextView
import android.widget.ToggleButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session

class MainActivity : AppCompatActivity() {

    private lateinit var surfaceView: GLSurfaceView
    private lateinit var tvInfo: TextView
    private lateinit var btnShoot: Button
    private lateinit var btnRecord: ToggleButton // Le nouveau bouton

    private var arCoreSession: Session? = null
    private val renderer = ARRenderer(this)
    private lateinit var recorder: ScreenRecorder
    private lateinit var projectionManager: MediaProjectionManager
    
    private val CODE_REC = 101
    private val CODE_PERM = 100
    private var isRunning = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        surfaceView = findViewById(R.id.surfaceview)
        tvInfo = findViewById(R.id.tvDistance)
        btnShoot = findViewById(R.id.btnShoot)
        btnRecord = findViewById(R.id.btnRecord) // Liaison XML

        recorder = ScreenRecorder(this)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        setupGL()

        // 1. Logique Capture (Ajouter Point)
        btnShoot.setOnClickListener {
            try {
                renderer.triggerCapture()
            } catch (e: Exception) {
                Toast.makeText(this, "Erreur Capture: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        // 2. Logique Vidéo (Séparée)
        btnRecord.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // Demande autorisation
                startActivityForResult(projectionManager.createScreenCaptureIntent(), CODE_REC)
            } else {
                // Stop
                recorder.stop()
                btnRecord.setBackgroundColor(Color.DKGRAY)
            }
        }

        checkPerms()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CODE_REC) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val metrics = DisplayMetrics()
                windowManager.defaultDisplay.getMetrics(metrics)
                recorder.start(resultCode, data, projectionManager, metrics)
                btnRecord.setBackgroundColor(Color.RED) // Feedback visuel
            } else {
                btnRecord.isChecked = false
            }
        }
    }

    // --- SETUP ARCORE ---
    private fun setupGL() {
        surfaceView.preserveEGLContextOnPause = true
        surfaceView.setEGLContextClientVersion(2)
        surfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        surfaceView.setRenderer(renderer)
        surfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
    }

    private fun checkPerms() {
        val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (ContextCompat.checkSelfPermission(this, perms[0]) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, perms, CODE_PERM)
        } else {
            initAR()
        }
    }

    override fun onRequestPermissionsResult(rq: Int, p: Array<String>, res: IntArray) {
        if (rq == CODE_PERM && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) initAR()
    }

    private fun initAR() {
        try {
            if (ArCoreApk.getInstance().checkAvailability(this).isSupported) {
                arCoreSession = Session(this)
                val config = Config(arCoreSession)
                config.focusMode = Config.FocusMode.AUTO
                config.depthMode = Config.DepthMode.DISABLED
                config.instantPlacementMode = Config.InstantPlacementMode.LOCAL_Y_UP
                arCoreSession?.configure(config)
                renderer.currentSession = arCoreSession
                arCoreSession?.resume()
                
                // UI Loop
                Thread {
                    while (isRunning) {
                        try {
                            Thread.sleep(100)
                            val m = renderer.uiMessage
                            runOnUiThread { tvInfo.text = m }
                        } catch(e:Exception){}
                    }
                }.start()
            }
        } catch (e: Exception) { }
    }

    override fun onResume() { super.onResume(); surfaceView.onResume(); arCoreSession?.resume() }
    override fun onPause() { super.onPause(); surfaceView.onPause(); arCoreSession?.pause() }
    override fun onDestroy() { super.onDestroy(); arCoreSession?.close(); isRunning = false; recorder.stop() }
}
