package com.piink.proto

import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.util.DisplayMetrics
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScreenRecorder(private val context: Context) {

    private var mediaRecorder: MediaRecorder? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaProjection: MediaProjection? = null
    private var videoFile: File? = null
    var isRecording = false; private set

    fun start(resultCode: Int, data: Intent, mpManager: MediaProjectionManager, metrics: DisplayMetrics) {
        try {
            initRecorder(metrics)
            mediaProjection = mpManager.getMediaProjection(resultCode, data)
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "PiinkRec", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, mediaRecorder?.surface, null, null
            )
            mediaRecorder?.start()
            isRecording = true
            Toast.makeText(context, "Enregistrement VIDEO (Sans son)", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            isRecording = false
            Toast.makeText(context, "Erreur Rec: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun initRecorder(metrics: DisplayMetrics) {
        val dir = context.getExternalFilesDir(null)
        val time = SimpleDateFormat("HHmmss", Locale.US).format(Date())
        videoFile = File(dir, "PIINK_$time.mp4")

        // Optimisation Xperia 1 : 1080p
        val w = (metrics.widthPixels / 2 / 16) * 16
        val h = (metrics.heightPixels / 2 / 16) * 16

        mediaRecorder = MediaRecorder().apply {
            // SUPPRESSION DE LA SOURCE AUDIO POUR EVITER LE CRASH
            // setAudioSource(MediaRecorder.AudioSource.MIC) 
            
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(videoFile?.absolutePath)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            
            // Pas d'encodeur Audio non plus
            // setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            
            setVideoEncodingBitRate(6000000)
            setVideoFrameRate(30)
            setVideoSize(w, h)
            prepare()
        }
    }

    fun stop() {
        if (!isRecording) return
        try {
            mediaRecorder?.stop()
            mediaRecorder?.reset()
        } catch (e: Exception) {} 
        finally {
            virtualDisplay?.release()
            mediaProjection?.stop()
            isRecording = false
            videoFile?.let {
                MediaScannerConnection.scanFile(context, arrayOf(it.absolutePath), null, null)
                Toast.makeText(context, "Sauvegardé : ${it.name}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
